--
-- Database: `online_exam`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CategoryId` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `IsActive` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CategoryId`, `Name`, `IsActive`) VALUES
(1, 'Aptitude', 1),
(2, '.Net', 1),
(3, 'Android', 1),
(4, 'PHP', 1),
(5, 'HTML', 1),
(6, 'CSS', 1),
(7, 'Java', 0),
(8, '#C', 0),
(9, 'Ajax', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductId` int(11) NOT NULL,
  `Question` blob,
  `OptionA` blob,
  `OptionB` blob,
  `OptionC` blob,
  `OptionD` blob,
  `Answer` tinyint(4) DEFAULT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `DifficultId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductId`, `Question`, `OptionA`, `OptionB`, `OptionC`, `OptionD`, `Answer`, `CategoryId`, `DifficultId`) VALUES
(3, 0x74657374, 0x7465737431, 0x7465737432, 0x5465737433, 0x7465737434, 0, NULL, NULL),
(4, 0x74657374, 0x74657374, 0x74657374, 0x74657374, 0x74657374, 3, NULL, NULL),
(5, 0x4120706572736f6e2063726f73736573206120363030206d206c6f6e672073747265657420696e2035206d696e757465732e20576861742069732068697320737065656420696e206b6d2070657220686f75723f, 0x332e36, 0x372e32, 0x382e34, 0x3130, 2, NULL, NULL),
(6, '', '', '', '', '', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserId` int(11) NOT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `UserName` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserId`, `FirstName`, `LastName`, `UserName`, `Password`, `Email`, `Phone`) VALUES
(1, 'Admin', 'Bit', 'admin', 'admin', 'admin@bit.com', 2147483647),
(2, 'Sarthak', 'Shah', 'sarthakshah', 'sarthak', 'sarthak@shah.com', 9898989898);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CategoryId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductId`),
  ADD KEY `ForeignKey` (`CategoryId`),
  ADD KEY `DifficultyLevelId` (`DifficultId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `CategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `fk_category_id` FOREIGN KEY (`CategoryId`) REFERENCES `category` (`CategoryId`),
  ADD CONSTRAINT `fk_difficulty_id` FOREIGN KEY (`DifficultId`) REFERENCES `difficulty` (`DifficultyId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
